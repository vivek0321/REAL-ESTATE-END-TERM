export const InitialFeedback = {
    propertytitle: '',
    for: 'Sale',
    bedrooms: '',
    bathrooms: '',
    garage: false,
    lounge: false,
    price:  '',
    priceUnit:'Lac',
    area:'',
    areaUnit:'Marla',
    address:'',
    contact:'',
    city:'Rawalpindi',
    description: ''
};
export const ContactForm = {
  name:'',
  contactNumber:'',
  emailAddress:'',
  message:''
};