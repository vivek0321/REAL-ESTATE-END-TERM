import React, {Component, Fragment} from 'react';



class AdminDashboard extends Component {

    render() {
        return (
            <Fragment >
               <div >
                    <h1>Admin Dashboard Component</h1>
               </div>
            </Fragment>
        );
    }
}

export default AdminDashboard;